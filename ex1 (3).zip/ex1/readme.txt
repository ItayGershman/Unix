README
Name: Itay Gershman
Id: 312491798

name: Chen Gutman
id: 205616147

name: Omer Ben Simon
id: 316110246
-‫----------------------------------------------------------------‬
 
client:
------------------
client app connects on port 50000

info:
the client communicate with the server.
the files that receive from the server store on the client folder.
the client can store and send any kind of files.

include:
client.c client.o

server:
------------------
server app connects on port 50000.

info:
server can manage multiple clients. 
the server can store and send any kind of files. 

include:
server.c server.o  
-----------------------
Files:
a.txt b.txt c.txt

submission date: 21.8.19
